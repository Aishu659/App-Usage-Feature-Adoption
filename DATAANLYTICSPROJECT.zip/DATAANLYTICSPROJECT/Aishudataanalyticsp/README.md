# App Usage & Feature Adoption

## Project overview
This project uses the ready-made Kaggle dataset `SaaS Subscription & Churn Analytics Dataset` from Rivalytics. It addresses the business question:

> Which features drive retention?

The dataset is public and matches the academic requirement for a Kaggle dataset. The source README explicitly states the data is synthetic and contains intended nulls, which are kept only where they occur naturally in the source dataset.

## Files
- data/raw/: original downloaded Kaggle CSV files
- data/cleaned/: cleaned CSV tables used for the analysis
- docs/problem_statement_and_data_dictionary.md: business problem statement and detailed data dictionary
- docs/data_quality_issues.md: actual issues identified and actions taken
- sql/feature_retention_analysis.sql: SQL queries for retention and feature analysis
- notebooks/feature_retention_analysis.ipynb: Jupyter notebook with exploratory analysis and charts

## Business question
Which product features are associated with higher customer retention, and which features show the strongest lift relative to non-adopters?

## Actual dataset facts
- Dataset name: SaaS Subscription & Churn Analytics Dataset
- Source: Rivalytics / Kaggle
- Dataset URL: https://www.kaggle.com/datasets/rivalytics/saas-subscription-and-churn-analytics-dataset
- License: MIT (Kaggle metadata); README describes it as MIT-like and fully synthetic
- Last updated: 2025-07-21T23:53:44.247Z

## A note on data quality
The source dataset contains real missing values in `feedback_text` and `satisfaction_score`. These were not invented or artificially added. The cleaning step only converted date columns to pandas datetime while preserving the original nulls and values.
