-- Feature retention analysis using real Kaggle SaaS data
-- Tables used: accounts, subscriptions, feature_usage, support_tickets, churn_events

-- 1. Total accounts and retention rate
SELECT COUNT(*) AS total_accounts,
       ROUND(AVG(CASE WHEN churn_flag = TRUE THEN 1.0 ELSE 0.0 END), 4) AS churn_rate,
       ROUND(1 - AVG(CASE WHEN churn_flag = TRUE THEN 1.0 ELSE 0.0 END), 4) AS retention_rate
FROM accounts;

-- 2. Active vs churned accounts by plan tier
SELECT a.plan_tier,
       COUNT(*) AS total_accounts,
       SUM(CASE WHEN a.churn_flag = TRUE THEN 1 ELSE 0 END) AS churned_accounts,
       ROUND(AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END), 4) AS churn_rate
FROM accounts a
GROUP BY a.plan_tier
ORDER BY churn_rate DESC;

-- 3. Feature adoption by account
SELECT f.feature_name,
       COUNT(DISTINCT s.account_id) AS adopting_accounts,
       ROUND(COUNT(DISTINCT s.account_id) * 100.0 / (SELECT COUNT(*) FROM accounts), 2) AS adoption_rate_pct
FROM feature_usage f
JOIN subscriptions s ON s.subscription_id = f.subscription_id
GROUP BY f.feature_name
HAVING COUNT(DISTINCT s.account_id) >= 300
ORDER BY adopting_accounts DESC;

-- 4. Feature-level retention among adopters
WITH feature_retention AS (
    SELECT f.feature_name,
           COUNT(DISTINCT s.account_id) AS adopting_accounts,
           AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END) AS churn_rate,
           1 - AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END) AS retention_rate
    FROM feature_usage f
    JOIN subscriptions s ON s.subscription_id = f.subscription_id
    JOIN accounts a ON a.account_id = s.account_id
    GROUP BY f.feature_name
)
SELECT feature_name,
       adopting_accounts,
       ROUND(retention_rate, 4) AS retention_rate,
       ROUND(churn_rate, 4) AS churn_rate
FROM feature_retention
ORDER BY retention_rate DESC;

-- 5. Retention lift vs. non-adopters
WITH feature_adoption AS (
    SELECT f.feature_name,
           COUNT(DISTINCT s.account_id) AS adopting_accounts,
           AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END) AS adopter_churn_rate
    FROM feature_usage f
    JOIN subscriptions s ON s.subscription_id = f.subscription_id
    JOIN accounts a ON a.account_id = s.account_id
    GROUP BY f.feature_name
),
all_accounts AS (
    SELECT account_id, churn_flag
    FROM accounts
),
feature_lift AS (
    SELECT fa.feature_name,
           fa.adopting_accounts,
           1 - fa.adopter_churn_rate AS adopter_retention,
           1 - AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END) AS non_adopter_retention,
           1 - AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END) - (1 - fa.adopter_churn_rate) AS retention_lift
    FROM feature_adoption fa
    JOIN feature_usage fu ON fu.feature_name = fa.feature_name
    JOIN subscriptions s ON s.subscription_id = fu.subscription_id
    JOIN all_accounts a ON a.account_id = s.account_id
    GROUP BY fa.feature_name, fa.adopting_accounts, fa.adopter_churn_rate
)
SELECT feature_name,
       adopting_accounts,
       ROUND(adopter_retention, 4) AS adopter_retention,
       ROUND(non_adopter_retention, 4) AS non_adopter_retention,
       ROUND(retention_lift, 4) AS retention_lift
FROM feature_lift
ORDER BY retention_lift DESC
LIMIT 10;

-- 6. Feature adoption vs. churn with CASE WHEN
SELECT f.feature_name,
       CASE WHEN COUNT(DISTINCT s.account_id) >= 350 THEN 'High adoption' ELSE 'Moderate adoption' END AS adoption_bucket,
       COUNT(DISTINCT s.account_id) AS adopting_accounts,
       ROUND(AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END), 4) AS churn_rate
FROM feature_usage f
JOIN subscriptions s ON s.subscription_id = f.subscription_id
JOIN accounts a ON a.account_id = s.account_id
GROUP BY f.feature_name
ORDER BY adopting_accounts DESC;

-- 7. Average usage days per account and one subquery
SELECT account_id,
       total_usage,
       CASE WHEN total_usage > 500 THEN 'High use' ELSE 'Normal use' END AS usage_bucket
FROM (
    SELECT s.account_id,
           SUM(f.usage_count) AS total_usage
    FROM feature_usage f
    JOIN subscriptions s ON s.subscription_id = f.subscription_id
    GROUP BY s.account_id
) usage_summary
WHERE total_usage > 500
ORDER BY total_usage DESC;

-- 8. Support ticket volume by priority and retention status
SELECT st.priority,
       COUNT(*) AS tickets,
       ROUND(AVG(CASE WHEN a.churn_flag = TRUE THEN 1.0 ELSE 0.0 END), 4) AS churn_rate_for_ticket_accounts
FROM support_tickets st
JOIN accounts a ON a.account_id = st.account_id
GROUP BY st.priority
ORDER BY tickets DESC;

-- 9. Churn reasons by category with window function
WITH churn_summary AS (
    SELECT ce.reason_code,
           COUNT(*) AS churn_count,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS rn
    FROM churn_events ce
    GROUP BY ce.reason_code
)
SELECT reason_code,
       churn_count,
       rn
FROM churn_summary
ORDER BY churn_count DESC;

-- 10. Feature usage intensity by plan tier and rank
WITH feature_usage_by_plan AS (
    SELECT s.plan_tier,
           f.feature_name,
           SUM(f.usage_count) AS feature_usage_total,
           RANK() OVER (PARTITION BY s.plan_tier ORDER BY SUM(f.usage_count) DESC) AS feature_rank
    FROM feature_usage f
    JOIN subscriptions s ON s.subscription_id = f.subscription_id
    GROUP BY s.plan_tier, f.feature_name
)
SELECT plan_tier,
       feature_name,
       feature_usage_total,
       feature_rank
FROM feature_usage_by_plan
WHERE feature_rank <= 3
ORDER BY plan_tier, feature_rank;
