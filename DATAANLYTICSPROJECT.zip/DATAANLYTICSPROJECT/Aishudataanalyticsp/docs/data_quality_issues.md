# Data Quality Issues and Cleaning Log

## Dataset used
Name: SaaS Subscription & Churn Analytics Dataset
Source: Kaggle (Rivalytics)
URL: https://www.kaggle.com/datasets/rivalytics/saas-subscription-and-churn-analytics-dataset

## Dataset profile before cleaning
- accounts: 500 rows, 10 columns
- subscriptions: 5,000 rows, 14 columns
- feature_usage: 25,000 rows, 8 columns
- support_tickets: 2,000 rows, 9 columns
- churn_events: 600 rows, 9 columns

## Actual issues found
| Issue | Column | Before | Action Taken | After | Reason |
|---|---|---:|---|---:|---|
| Missing values in text feedback | feedback_text | 148 nulls | Kept as nulls; no imputation | 148 nulls | This is a genuine observed gap in the Kaggle data, not an artificial defect |
| Missing values in satisfaction scores | satisfaction_score | 825 nulls | Kept as nulls; no imputation | 825 nulls | Source dataset intentionally includes missing satisfaction values |
| Null subscription end dates for active contracts | end_date | 4,514 nulls | Kept as nulls; no deletion | 4,514 nulls | These are active subscriptions and valid in the source data |
| Date fields not parsed as datetime | signup_date, start_date, end_date, usage_date, submitted_at, closed_at, churn_date | Strings | Converted to datetime format | Datetime dtype | Required for time-based retention and support analysis |

## Before and after counts
- Before row count: 500 + 5,000 + 25,000 + 2,000 + 600 = 32,? Wait, the tables are separate logical tables. The cleaned dataset preserved the same row counts per file.
- After row count: same as original for each file because only type-safe cleaning was applied.
- Before column count: accounts 10; subscriptions 14; feature_usage 8; support_tickets 9; churn_events 9
- After column count: unchanged

## Conclusion
No duplicate rows, no fabricated values, and no unnecessary deletions were applied. The cleaning is limited to converting date strings into valid datetime objects and preserving genuine nulls.
