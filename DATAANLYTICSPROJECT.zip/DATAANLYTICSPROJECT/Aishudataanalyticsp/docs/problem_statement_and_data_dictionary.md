# Business Problem Statement and Data Dictionary

## 1) Business problem statement
RavenStack is a SaaS company measuring customer retention across the product lifecycle. The business question is:

> Which features drive retention?

The sales and product teams need to know which features are most strongly associated with customers staying active versus churning. By analyzing account signups, subscriptions, usage logs, churn events, and support tickets, the organization can identify the product capabilities that improve retention, guide roadmap prioritization, and focus activation efforts on the features most likely to keep customers engaged.

The key KPIs to answer this question are:
- Overall retention rate = 1 - churn rate
- Feature adoption rate = % of accounts that used a specific feature
- Feature-level retention rate = % of adopters who remained active
- Retention lift = retention rate of feature adopters minus retention rate of non-adopters
- Average feature usage frequency and duration by account
- Churn reason distribution and support patterns

## 2) Dataset summary
- Kaggle dataset name: SaaS Subscription & Churn Analytics Dataset
- Kaggle source: Rivalytics
- Dataset URL: https://www.kaggle.com/datasets/rivalytics/saas-subscription-and-churn-analytics-dataset
- License: MIT (Kaggle metadata; README states MIT-like)
- Last updated: 2025-07-21T23:53:44.247Z

## 3) Data dictionary
### accounts
| Column Name | Description | Data Type | Example Value | Business Meaning | Possible Use in Analysis |
|---|---|---|---|---|---|
| account_id | Unique customer identifier | string | A-2e4581 | Primary key for customer-level analysis | Join to subscriptions and support tickets |
| account_name | Fictional company name | string | Company_0 | Human-readable company label | Reporting and aggregated segmentation |
| industry | Business sector | string | EdTech | Helps segment customer cohorts | Retention by industry |
| country | ISO country code | string | US | Geographic segmentation | Retention by country |
| signup_date | Account creation date | datetime | 2024-10-16 | Signals early tenure and acquisition behavior | Cohort and onboarding analysis |
| referral_source | Acquisition channel | string | partner | Explains how customers entered the product | Channel analysis |
| plan_tier | Initial plan selected | string | Basic | Shows customer entry tier | Onboarding and plan conversion analysis |
| seats | Number of licensed users | integer | 9 | Product scale at signup | Relationship between scale and retention |
| is_trial | Trial status | boolean | False | Shows if the account is still testing | Trial-to-paid conversion |
| churn_flag | Whether the account ever churned | boolean | False | Primary outcome variable | Retention modeling |

### subscriptions
| Column Name | Description | Data Type | Example Value | Business Meaning | Possible Use in Analysis |
|---|---|---|---|---|---|
| subscription_id | Unique subscription identifier | string | S-8cec59 | One record per billing lifecycle | Join to feature usage |
| account_id | Customer identifier | string | A-3c1a3f | Links subscription to account | Retention and churn rollups |
| start_date | Subscription start date | datetime | 2023-12-23 | Subscription start | Deployment and tenure analysis |
| end_date | Subscription end date | datetime | 2024-04-12 | Active or churned cycle end | Churn timing |
| plan_tier | Plan at time of billing | string | Enterprise | Product packaging | Retention by plan |
| seats | Licensed seats | integer | 14 | Product scale purchased | Revenue and usage segmentation |
| mrr_amount | Monthly recurring revenue | integer | 2786 | Revenue baseline | Monetization and churn analysis |
| arr_amount | Annual recurring revenue | integer | 33432 | Annualized revenue | Revenue-correlated retention |
| is_trial | Trial flag | boolean | False | Whether current subscription is trial | Trial retention analysis |
| upgrade_flag | Upgrade during cycle | boolean | False | Indicates expansion events | Feature to product adoption correlation |
| downgrade_flag | Downgrade during cycle | boolean | False | Indicates contraction | Retention risk analysis |
| churn_flag | Did the subscription end? | boolean | True | Lifecycle outcome | Retention analytics |
| billing_frequency | Monthly or annual billing | string | monthly | Revenue cadence | Monetization behavior |
| auto_renew_flag | Auto-renewal status | boolean | True | Renewal behavior | Renewal and retention analysis |

### feature_usage
| Column Name | Description | Data Type | Example Value | Business Meaning | Possible Use in Analysis |
|---|---|---|---|---|---|
| usage_id | Unique usage event identifier | string | U-1c6c24 | Each row is a usage record | Event-level analyses |
| subscription_id | Subscription identifier | string | S-0fcf7d | Links the usage event to a customer | Feature adoption analysis |
| usage_date | Date of usage | datetime | 2023-07-27 | Time dimension for use patterns | Trends and cohorts |
| feature_name | Product feature used | string | feature_20 | Product capability being exercised | Feature adoption and retention |
| usage_count | Frequency of usage events | integer | 9 | Intensity of feature engagement | Usage depth analysis |
| usage_duration_secs | Time spent in seconds | integer | 5004 | Engagement depth | Correlation with retention |
| error_count | Logged errors for the feature | integer | 0 | Reliability signal | Usage quality and churn signals |
| is_beta_feature | Beta flag | boolean | False | Distinguishes early features | Beta feature performance |

### support_tickets
| Column Name | Description | Data Type | Example Value | Business Meaning | Possible Use in Analysis |
|---|---|---|---|---|---|
| ticket_id | Unique ticket identifier | string | T-0024de | Case-level record | Support load analysis |
| account_id | Customer identifier | string | A-712f1c | Links support to customer | Support impact on churn |
| submitted_at | Ticket open date/time | datetime | 2023-07-27 | Support intake time | Timelines and SLA analysis |
| closed_at | Ticket close date/time | datetime | 2023-07-28 03:00:00 | Resolution timing | Service quality analysis |
| resolution_time_hours | Time to resolve | float | 27.0 | Operational performance | Resolution efficiency |
| priority | Ticket priority | string | high | Service urgency | Prioritization and support load |
| first_response_time_minutes | Minutes to first response | integer | 74 | Customer experience metric | Support responsiveness |
| satisfaction_score | Customer satisfaction rating | float | NaN | Service quality signal | Support impact on retention |
| escalation_flag | Escalation flag | boolean | False | Indicates escalated support cases | Complex issue analysis |

### churn_events
| Column Name | Description | Data Type | Example Value | Business Meaning | Possible Use in Analysis |
|---|---|---|---|---|---|
| churn_event_id | Unique churn event identifier | string | C-816288 | one churn event per row | Churn analytics |
| account_id | Customer identifier | string | A-c37cab | Links churn to customer | Cohort and churn segmentation |
| churn_date | Date of churn | datetime | 2024-10-27 | Churn time | Churn timing and lifecycle analysis |
| reason_code | Explanation category for churn | string | pricing | Churn driver category | Root-cause analysis |
| refund_amount_usd | Refund issued | float | 4.03 | Revenue recovery signal | Churn cost analysis |
| preceding_upgrade_flag | Prior upgrade before churn | boolean | False | Indicates expansion before churn | Upgrade-to-churn dynamics |
| preceding_downgrade_flag | Prior downgrade before churn | boolean | False | Indicates contraction before churn | Retention risk signal |
| is_reactivation | Reactivation flag | boolean | False | Indicates churn followed by return | Win-back analysis |
| feedback_text | Customer churn feedback | string | switched to competitor | Qualitative churn reason | Text analysis and root-cause exploration |

## 4) Data quality review
This dataset naturally includes nulls and valid missing values. The application of cleaning was limited to converting string dates to datetime and preserving the real nulls already present in the source data.

## 5) Business use case
The product and retention teams can identify which features correlate with higher customer stability, then prioritize the most effective features for onboarding, growth, and customer success interventions.
